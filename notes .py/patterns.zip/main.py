# n=5
# for i in range(1, n+1):
#     for j in range(1,i+1):
#         print('*', end=" ")
#     print() 
# n=4
# c=1
# for i in range(1,n+1):
#     for j in range(1,i+1):
#         print(c,end="s")
#         c=c+1
#     print()
# print(c)
#n=5
'''for i in range(5,0,-1):
    for j in range(i):
        print("*", end="")
    print() '''
'''k=n
for i in range(1,n+1):
    for j in range(1,k+1):
        print("*",end="")
    k=k-1
    print()'''
#c=10
'''for i in range(4,0,-1):
    for j in range(i):
        print(c,end=" ")
        c=c-1
#     print() '''
# for i in range(1,n+1):
#     for j in range(1,i+1):
#         print(j,end="")
#     print() 
'''n = 6
for i in range(1,n+1):
    for j in range(n-i,0,-1):
        print(" ",end="")
    for k in range(1, 2 * i):
        print("*",end="")
    print()'''
# n=5
# for i in range(1,n+1):
#     for j in range(1,i):
#         print(" ",end="")
#     for k in range(2*(n-i)+1):
#         print("*",end="")
#     print()    
        
   


        
    
    