'''a = int(input())
if a%4==0 and a%100!=0 or a%400==0:
    print("It's a leap year")
else:
    print("It's not a leap year")'''
'''Calculate the sum of numbers from 1 to 10 using a for loop ? '''
'''s = 0
for i in range(1,11):
    s+=i
print(s)'''
'''Print even numbers from 1 to 10 using a for loop?'''
'''for i in range(0,11):
    if i%2==0:
        print(i)'''
'''multiplycation iof even numbers upto 20'''
'''m = 1
for i in range(1,21):
    if i%2==0:
        m*=i
print(m)'''
'''Calculate the factorial of a number using a for loop?'''
'''n = int(input())
fact = 1
for i in range(1,n+1):
    fact = fact*i
print(fact) '''
'''Print elements of a list using a for loop ?'''
'''l1=[1,2,3,4,5]
for i in range(len(l1)):
    print(l1[i])'''
'''Find the maximum value in a list using a for loop ?'''
'''l1=[5,8,11,23,67]
for i in range(len(l1)):
    max>l1:
        print
(l1[i])'''
'''n=int(input("Enter the cube numbers:"))
for i in range(1,n+1):
    cube=i*i*i
    print(cube-)'''
    
'''name = "shivasairam" 
vowels = "aeiou"
count =0
for char in name:
    if char not in vowels:
        count+=1

    
print(count)'''

'''s = 0
for i in range(1,100,2):
    s+=i
print(s)'''
'''Print the first 10 Fibonacci numbers using a for loop ?'''
f = 0
for i in range(1,11):
    f = f+i+f
print(f)






    

    

    
