# def student():
#     name='Ram'
#     print(name)
# student()
# company="codegnan"
# def Display():
#     print(f"Inside the function",company)
# Display()  
# print(f"Outside the function",company)
# company="codegnan"
# def Display():
#     print(f"Inside the function",company)
# print("end")    
# Display()  
# print(f"Outside the function",company)
# print("start-2")
# number=10
# def update():
#     number=100
#     print("inside the number",number)
# update()
# print("outside the function",number)
# number=10 global keyword it is used as the inside the global vatiable that modiefies the global key word
# def update():
#     global number
#     number=100
#     print("inside the number",number)
# update()
# print("outside the function",number)

#non local scop:(nested is the function in the another function is called nested)
# def Outer():
#     def Inner():
#         print("Inner the function")
#     Inner()
#     print("Outer the function")
# Outer() 
# print("End")
# n=10
# def Outer():
#     a=50
#     def Inner():
#         nonlocal a
#         a=100
#         print("inner function",a)
#     Inner()
#     print("outside inner",a)
# print("start")    
# Outer()
# print("End")
# python technologies is used as the object reference
# for learning purpose 
# call by values:immutable objects
# call by reference :mutable objects
# call by values:when immutable pass the function changes inside the function does not effect the origin value
# def Update():
#     number=209
# number=100
# print("inside the function num",number)
# Update()
# print("Outside the function",number)
#call by reference:when mutable objects pass the function changes inside the function it's effect the original values
def shopping(cart):
    cart.append("orange")
cart=["apple","banana","stawberry"]
print("inside the function",cart)
shopping(cart)
print("outside the function",cart)